const mongoose = require('mongoose');

mongoose.set('strictQuery', false); // DeprecationWarning'i önlemek için

async function connect() {
  try {
    await mongoose.connect("mongodb+srv://skypieacraft:5DHzIcSRbkzskCug@cluster0.dr6awba.mongodb.net", {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      // useFindAndModify ve useCreateIndex seçeneklerini kaldırıyoruz
    });
    console.log("Connected to the database!");
  } catch (e) {
    console.log(e);
  }
}

connect();
